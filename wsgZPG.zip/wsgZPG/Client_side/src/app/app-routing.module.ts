import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoginComponent } from './login/login.component';


import { RegisterModulComponent } from './register-modul/register-modul.component';
import { ResetPassModulComponent } from './reset-pass-modul/reset-pass-modul.component';
import { LogoutModulComponent } from './logout-modul/logout-modul.component';
import { Level1Component } from './level1/level1.component';
import { Level2Component } from './level2/level2.component';
import { Level3Component } from './level3/level3.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  
  { path: 'register', component: RegisterModulComponent },
  { path: 'resetpass', component: ResetPassModulComponent },

  { path: 'home', component: HomeComponent,
  children: [
    { path: 'level1', component: Level1Component},
    { path: 'level2', component: Level2Component},
    { path: 'level3', component: Level3Component},
  ] },

  { path: '', redirectTo: '/login', pathMatch:'full' },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
