import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-level2',
  templateUrl: './level2.component.html',
  styleUrls: ['./level2.component.css']
})
export class Level2Component implements OnInit {

  list=[1,2,3,4,5,6,7,8,9,10 ];

  words=["CONDITION", "MEALS", "OFFER", "DYNAMIC", "BEECH", "FRUIT" ];
  



  constructor() { }

  private randomString(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
 }

 
  ngOnInit(): void {
  }

}
