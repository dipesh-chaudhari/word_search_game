import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LogoutModulComponent } from '../logout-modul/logout-modul.component';
import { ModalRulesComponent } from '../modal-rules/modal-rules.component';
import { faPuzzlePiece } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public faPuzzlePiece = faPuzzlePiece;
  constructor( private router: Router, private modalService: NgbModal ) { }

  ngOnInit(): void {
   if(!sessionStorage.getItem('sid')){
    this.router.navigate(['login']);}
 }

 processRules(){
  this.modalService.open(ModalRulesComponent,{
    scrollable: true,
  }); 
 }

  processlogout(){
    //open modal
    this.modalService.open(LogoutModulComponent,{
      centered:true,
    });
  }


}
