import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-logout-modul',
  templateUrl: './logout-modul.component.html',
  styleUrls: ['./logout-modul.component.css']
})
export class LogoutModulComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal, private router: Router) {}

  ngOnInit(): void {
  }

  closeTheModal(){
    this.activeModal.dismiss();
  }

  logOutAndClose(){
    sessionStorage.removeItem('sid');

    this.activeModal.dismiss();

    this.router.navigate(['login'])
  }

}
