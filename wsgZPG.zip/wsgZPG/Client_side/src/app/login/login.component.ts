import { Component, OnInit } from '@angular/core';
import {  } from '@angular/core';

import { Validators, FormBuilder,FormGroup, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public uiInvalidCredential = false;

  public fbFormGroup = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  constructor(
    private fb : FormBuilder,
    private router : Router,
    private http : HttpClient,
   
  ) { }

  ngOnInit(): void { }



 async loginProcessHere(){
    const data= this.fbFormGroup.value;
    
    const url ='http://localhost:4400/auth-user';
    const result : any = await this.http.post(url,data).toPromise();
    if(result.opr){
      sessionStorage.setItem('sid', 'true');
      this.router.navigate(['home']);
    }
    else{
      this.uiInvalidCredential = true;
    }
  }

}
