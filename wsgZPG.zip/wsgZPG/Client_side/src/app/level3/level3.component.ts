import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-level3',
  templateUrl: './level3.component.html',
  styleUrls: ['./level3.component.css']
})
export class Level3Component implements OnInit {

  list=[1,2,3,4,5,6,7,8,9,10 ];

  words=["ANDORRA", "ITALY", "DENMARK", "AUSTRALIA","ZAMBIA", "BULGARIA", "AFGHANISTAN", "ENGLAND", "NIGERIA" ];
  



  constructor() { }

  private randomString(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
 }

 
  ngOnInit(): void {
  }

}
