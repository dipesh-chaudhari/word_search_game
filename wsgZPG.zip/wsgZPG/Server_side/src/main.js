const express= require("express");
const cors = require("cors");
const multer = require("multer");
const app = express();
const dbadd= require("./add");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended:true}))
const upload = multer();




app.post("/adduser", async (req,res)=>{

    try{

        const input= req.body;

        await dbadd.addUser(input)

        res.json({massage: "success"})

    }
    catch(err){

        res.json({massage: "Error "})

    }

});

app.post("/auth-user", async (req,res)=>{
    try{
        const input = req.body;

        await dbadd.authenticateUser(input);
        res.json({ opr : true});
    }catch(err){
        res.json({ opr : false});
    }
});

app.post("/reset-pass", async (req,res)=>{
    try{
        const input = req.body;

        await dbadd.updatepass(input);
        res.json({ opr : true});
    }catch(err){
        res.json({ opr : false});
    }
});


app.listen(4400);