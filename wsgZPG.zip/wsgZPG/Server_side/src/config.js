

let configDB = {
    host     : '127.0.0.1',
    user     : 'root',
    password : 'Dip@1696',
    database : 'wsg',
  };

  module.exports ={configDB}