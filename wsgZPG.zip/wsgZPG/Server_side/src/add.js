const Promise = require("bluebird");
const mysql = require("mysql");
const config = require("./config");
Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let addUser= async(input)=>{
    console.log(input)
    let connection = mysql.createConnection(config.configDB);
    await connection.connectAsync();

    let sql ="insert into user(username,email,password,dob) values (?,?,?,?)";

    await connection.queryAsync(sql,[input.username,input.email,input.password,input.dob,]);
    await connection.endAsync();
}

let authenticateUser= async(input)=>{
    
    let connection = mysql.createConnection(config.configDB);
    await connection.connectAsync();

    let sql ="select * from user where username=? and password=?";

    let results = await connection.queryAsync(sql,[input.username,input.password,]);
    await connection.endAsync();

    if (results.length === 0){
        throw new Error("Invalid Credentials");
    }
}

let updatepass= async(input)=>{
    console.log(input)
    let connection = mysql.createConnection(config.configDB);
    await connection.connectAsync();

    if (input.password != input.repassword){
        throw new Error("Invalid repassword");
    }

    let sql ="update user set password=? where email=? and username=? ";

    let results = await connection.queryAsync(sql,[input.password,input.email,input.username,]);
    
    

    await connection.endAsync();

    if (results.length === 0){
        throw new Error("Invalid Credentials");
    }
}
module.exports= {
    addUser,authenticateUser,updatepass
};